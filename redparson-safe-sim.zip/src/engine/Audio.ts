import { DEFAULT_SAFE } from "./Core";

export class AudioLayer {
  ctx: AudioContext;
  master: GainNode;
  private sources: Set<AudioBufferSourceNode | OscillatorNode> = new Set();
  private cleanupTimer?: number;

  constructor() {
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.master = this.ctx.createGain();
    this.master.gain.value = Math.pow(10, DEFAULT_SAFE.audioMaxDb / 20);
    this.master.connect(this.ctx.destination);
  }

  resume() {
    if (this.ctx.state === "suspended") this.ctx.resume();
  }

  burst(frequency = 440, duration = 0.12, volume = 0.4) {
    this.resume();
    const t0 = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    this.sources.add(osc);

    osc.type = "triangle";
    osc.frequency.value = frequency;
    gain.gain.value = Math.min(volume, 0.8);

    osc.connect(gain).connect(this.master);
    osc.start(t0);
    osc.stop(t0 + duration);
    osc.frequency.linearRampToValueAtTime(frequency * 1.6, t0 + duration);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + duration);

    const clean = () => { this.sources.delete(osc); };
    osc.onended = clean;
    if (this.cleanupTimer) clearTimeout(this.cleanupTimer);
    this.cleanupTimer = window.setTimeout(clean, (duration + 0.1) * 1000);
  }

  playBuffer(buffer: AudioBuffer, loop = false, volume = 0.8) {
    this.resume();
    const src = this.ctx.createBufferSource();
    const gain = this.ctx.createGain();
    this.sources.add(src);

    src.buffer = buffer;
    src.loop = loop;
    gain.gain.value = Math.min(volume, 0.8);

    src.connect(gain).connect(this.master);
    src.start();
    src.onended = () => this.sources.delete(src);
    return src;
  }

  setMasterVolume(db: number) {
    this.master.gain.value = Math.pow(10, Math.min(db, DEFAULT_SAFE.audioMaxDb) / 20);
  }

  dispose() {
    for (const src of this.sources) {
      try { src.stop(); } catch (_) { /* already stopped */ }
    }
    this.sources.clear();
    this.master.disconnect();
  }
}
