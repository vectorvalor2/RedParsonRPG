import * as THREE from "three";
import {
  RenderPipeline,
  EditorTools,
  PhysicsLayer,
  SafetyLayer,
  SemanticGraph,
  CheckpointStack,
  SceneSerializer,
  AssetRegistry,
  golden,
} from "./engine/index";

// ── Bootstrap ──────────────────────────────────────────────
const el = document.getElementById("viewport")!;
const semantics = new SemanticGraph();
const safety = new SafetyLayer(semantics);
const pipe = new RenderPipeline(el, safety);
const editor = new EditorTools(pipe, pipe.assets);
const checkpoints = new CheckpointStack(64);

// ── Map & lighting ────────────────────────────────────────
pipe.map.addGround(40);
pipe.map.addLight();

// ── Spawn primitives ──────────────────────────────────────
const meshes: THREE.Object3D[] = [];
for (let i = 0; i < 24; i++) {
  const hue = i / 24;
  const color = new THREE.Color().setHSL(hue, 0.55, 0.5).getHex();
  const box = editor.spawnBox(`box-${i}`, 0.55, color);
  meshes.push(box);
  checkpoints.register(box, `box-${i}`);
}

// ── Golden-ratio spiral layout ────────────────────────────
pipe.transforms.applyGoldenLayout(meshes);

// ── Physics bodies ────────────────────────────────────────
const phys = pipe.physics as PhysicsLayer;
meshes.forEach((m) => {
  phys.addBody({
    object: m,
    velocity: new THREE.Vector3(
      (Math.random() - 0.5) * 0.4,
      Math.random() * 1.2,
      (Math.random() - 0.5) * 0.4
    ),
    mass: 1,
    restitution: 0.45,
  });
});

// ── Semantic tagging example ──────────────────────────────
const surfaceTag = semantics.addTag({
  id: "tag-surface-table",
  kind: "surface",
  label: "table",
  confidence: 0.92,
});
const plugTag = semantics.addTag({
  id: "tag-plug-leg",
  kind: "plug",
  label: "leg",
  confidence: 0.88,
});
semantics.link(surfaceTag.id, plugTag.id, "surface-to-surface");

// ── Initial checkpoint ────────────────────────────────────
checkpoints.snapshot("initial layout");

// ── Camera orbit ──────────────────────────────────────────
let az = 0;
function moveCamera(dt: number) {
  az += dt * 0.12;
  const r = 10;
  pipe.renderer.camera.position.set(
    Math.cos(az) * r,
    5.5,
    Math.sin(az) * r
  );
  pipe.renderer.camera.lookAt(0, 0.5, 0);
}

// ── HUD elements ──────────────────────────────────────────
const fpsEl = document.getElementById("fps")!;
const confEl = document.getElementById("conf")!;
const gateEl = document.getElementById("gate")!;
const guideCvs = document.getElementById("guides") as HTMLCanvasElement;

// ── Golden-ratio guide overlay ────────────────────────────
function drawGuides() {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  guideCvs.width = innerWidth * dpr;
  guideCvs.height = innerHeight * dpr;
  guideCvs.style.width = innerWidth + "px";
  guideCvs.style.height = innerHeight + "px";
  const ctx = guideCvs.getContext("2d")!;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, innerWidth, innerHeight);

  const phi = golden(1);
  const x1 = innerWidth / phi;
  const x2 = innerWidth - x1;
  const y1 = innerHeight / phi;
  const y2 = innerHeight - y1;

  ctx.strokeStyle = "rgba(45,212,191,0.22)";
  ctx.lineWidth = 1;
  ctx.setLineDash([6, 18]);
  ctx.beginPath();
  ctx.moveTo(x1, 0); ctx.lineTo(x1, innerHeight);
  ctx.moveTo(x2, 0); ctx.lineTo(x2, innerHeight);
  ctx.moveTo(0, y1); ctx.lineTo(innerWidth, y1);
  ctx.moveTo(0, y2); ctx.lineTo(innerWidth, y2);
  ctx.stroke();
  ctx.setLineDash([]);
}
addEventListener("resize", () => {
  pipe.renderer.resize();
  drawGuides();
});
drawGuides();

// ── Keyboard shortcuts ────────────────────────────────────
addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "z") {
    e.preventDefault();
    if (e.shiftKey) checkpoints.redo();
    else checkpoints.undo();
  }
});

// ── Main loop ─────────────────────────────────────────────
let last = performance.now();
let frames = 0;
let acc = 0;
const confidences: number[] = [];

function tick(t: number) {
  const dt = Math.min(0.033, (t - last) / 1000);
  last = t;

  phys.step(dt);
  moveCamera(dt);

  // Aggregate confidence
  confidences.length = 0;
  for (const asset of pipe.assets.all()) {
    confidences.push(asset.confidence.score);
  }
  const avgConf =
    confidences.length > 0
      ? confidences.reduce((a, b) => a + b, 0) / confidences.length
      : 0;
  confEl.textContent = avgConf.toFixed(3);

  const gateOpen = avgConf >= safety.cfg.minConfidence;
  gateEl.textContent = gateOpen ? "open" : "closed";
  gateEl.className = gateOpen ? "ok" : "bad";

  // Wireframe fallback when gate is closed
  meshes.forEach((m) => {
    const mesh = m as THREE.Mesh;
    if (Array.isArray(mesh.material)) return;
    (mesh.material as THREE.MeshStandardMaterial).wireframe = !gateOpen;
  });

  pipe.renderer.draw(pipe.graph.scene);

  // FPS counter
  acc += dt;
  frames++;
  if (acc >= 0.5) {
    fpsEl.textContent = String(Math.round(frames / acc));
    acc = 0;
    frames = 0;
  }

  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

// ── Drag-and-drop editing ─────────────────────────────────
const canvas = pipe.renderer.canvas;
editor.dragAndDropEnable(canvas);

// ── Startup SFX ───────────────────────────────────────────
editor.audio.burst(660, 0.08, 0.3);

// ── Hide loader ───────────────────────────────────────────
setTimeout(() => {
  document.getElementById("loader")?.classList.add("hidden");
}, 600);

// ── Expose for dev console ────────────────────────────────
Object.assign(window, {
  __red: { pipe, editor, safety, semantics, checkpoints, assets: pipe.assets },
});

console.log(
  "%cREDPARSON Safe Sim %cready",
  "color:#2dd4bf;font-weight:bold;font-size:16px",
  "color:#9e9ea8"
);
console.log(
  "Try: __red.checkpoints.undo() | __red.safety.audit(__red.assets.all()) | __red.editor.spawnSphere('test', 0.5, 0x3b82f6)"
);
