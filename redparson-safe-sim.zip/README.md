# REDPARSON Safe Sim

**Confidence-gated 3D game engine shell** — built on Three.js with integrated safety layers, semantic interlinking, undo/redo checkpoints, golden-ratio layout tools, and `.red` scene serialization.

```bash
npm install
npm run dev     # → http://localhost:5173
```

---

## Architecture

```
src/engine/
├── Core.ts          # Types, math utils, golden ratio helpers
├── SceneGraph.ts    # Tree-based scene graph with SGNode wrapper
├── Assets.ts        # Asset registry with confidence scoring
├── Loaders.ts       # GLTF/DRACO loader with progress events
├── Safety.ts        # Safety layer — risk gating, scene audit, debug bounds
├── Semantic.ts      # Tag graph — socket/plug/surface/anchor/volume/trigger rules
├── Checkpoint.ts    # Undo/redo transform checkpoint stack
├── Serialization.ts # .red scene format — export / import
├── Physics.ts       # Simple rigid-body physics with energy cap
├── Audio.ts         # Web Audio layer with master gain ceiling
├── Renderer.ts      # Three.js WebGL renderer + perspective camera
├── Layers.ts        # MapLayer, TransformLayer, RenderPipeline
├── Editor.ts        # Editor tools — spawn, drag-and-drop
└── index.ts         # Barrel re-exports
```

---

## Key concepts

### Confidence scoring

Every asset carries a `ConfidenceScore` (0–1) computed from provenance, mesh complexity, file size, and unsafe hints. The **safety gate** blocks low-confidence assets from entering the viewport (or reverts them to wireframe). The threshold defaults to 0.62 — a golden-ratio inflection point.

### Semantic interlinking

Tag objects with semantic kinds — `socket`, `plug`, `surface`, `anchor`, `volume`, `trigger` — then define `InterlinkRule` entries that govern how tags connect. The `SemanticGraph.findCandidates()` method discovers all valid link partners, and `riskScore()` produces a graph-wide health metric.

### Undo / redo

`CheckpointStack` snapshots position/rotation/scale/visibility for every registered `Object3D`. Call `snapshot("label")` before making changes, then `undo()` and `redo()`. Keyboard shortcuts: Ctrl+Z / Ctrl+Shift+Z.

### .red scene files

`SceneSerializer.export()` produces a JSON object with every asset's metadata, confidence, transform, source URL, and semantic tags. `import()` rebuilds the scene graph from a `.red` file.

### Safety audit

```ts
const report = safety.audit(assets.all());
// → { overallRisk, score, assetRisks, semanticRisk, recommendations }
```

Monitors triangle budgets (2M default), draw-call limits (2K), average asset confidence, and semantic graph health — returns color-coded risks with actionable recommendations.

---

## Quick API

```ts
import * as RED from "./src/engine/index";

// Create pipeline
const semantics = new RED.SemanticGraph();
const safety = new RED.SafetyLayer(semantics);
const pipe = new RED.RenderPipeline(document.getElementById("viewport")!, safety);

// Load a GLB
const loader = new RED.AssetLoader(pipe.assets);
const asset = await loader.loadGLTF("/model.glb", {
  id: "chair-1", tags: ["furniture"], sizeBytes: 0, provenance: "local", complexity: 0.3,
});
pipe.promote(asset!);

// Tag & link
const s = semantics.addTag({ id: "seat", kind: "socket", label: "seat", confidence: 0.9 });
const p = semantics.addTag({ id: "leg", kind: "plug", label: "leg", confidence: 0.85 });
semantics.link(s.id, p.id, "plug-into-socket");

// Undo / redo
const cp = new RED.CheckpointStack(64);
cp.register(asset!.object);
cp.snapshot("before move");
asset!.object.position.x += 3;
cp.undo();

// Serialize
const serializer = new RED.SceneSerializer(pipe.assets, semantics, cp);
const json = serializer.stringify(serializer.export("My Scene"));
```

---

## Dev console

After the demo loads, `__red` is exposed on `window`:

```js
__red.checkpoints.undo()
__red.safety.audit(__red.assets.all())
__red.editor.spawnSphere("test", 0.5, 0x3b82f6)
```

---

## License

MIT
